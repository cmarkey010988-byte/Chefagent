package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.example.data.local.entities.SyncEventEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SyncEventDao {

    @Query("SELECT * FROM sync_event_queue WHERE isSynced = 0 ORDER BY sequenceId ASC")
    fun observePendingEvents(): Flow<List<SyncEventEntity>>

    @Query("SELECT * FROM sync_event_queue ORDER BY sequenceId DESC LIMIT 50")
    fun observeRecentEvents(): Flow<List<SyncEventEntity>>

    @Query("SELECT * FROM sync_event_queue WHERE isSynced = 0 ORDER BY sequenceId ASC")
    suspend fun getPendingEvents(): List<SyncEventEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSyncEvent(event: SyncEventEntity): Long

    @Query("UPDATE sync_event_queue SET isSynced = 1 WHERE eventId IN (:eventIds)")
    suspend fun markEventsAsSynced(eventIds: List<String>)

    @Query("DELETE FROM sync_event_queue WHERE isSynced = 1")
    suspend fun clearSyncedEvents()

    @Transaction
    suspend fun markAllPendingAsSynced() {
        val pending = getPendingEvents().map { it.eventId }
        if (pending.isNotEmpty()) {
            markEventsAsSynced(pending)
        }
    }
}
