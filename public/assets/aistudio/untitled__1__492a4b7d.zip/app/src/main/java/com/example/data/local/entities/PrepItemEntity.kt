package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "prep_items")
data class PrepItemEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val recipeId: String,
    val recipeName: String,
    val targetQuantity: Double,
    val completedQuantity: Double = 0.0,
    val unitOfMeasure: String,
    val stationAssignment: String, // "Sauce/Sauté", "Butchery", "Garde Manger", "Pastry"
    val priorityLevel: Int, // 1 = Critical/Banquet, 2 = Standard Par, 3 = Low
    val isCompleted: Boolean = false,
    val assignedCookName: String? = null,
    val shiftedDateTimestamp: Long = System.currentTimeMillis()
)
