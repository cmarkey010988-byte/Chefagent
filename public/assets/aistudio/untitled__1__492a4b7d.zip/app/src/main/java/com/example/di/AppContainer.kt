package com.example.di

import android.content.Context
import com.example.data.local.ChefAgentDatabase
import com.example.data.local.SeedDataGenerator
import com.example.data.repository.BanquetRepository
import com.example.data.repository.InventoryRepository
import com.example.data.repository.PrepRepository
import com.example.data.repository.RecipeRepository
import com.example.data.repository.SyncRepository
import com.example.domain.usecase.CalculateRecipeCostUseCase
import com.example.domain.usecase.GenerateDailyPrepListUseCase
import com.example.domain.usecase.ScaleRecipeQuantityUseCase
import com.example.sync.PeerSyncEngine
import com.example.ui.profile.ProfileStateManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AppContainer(private val context: Context) {

    private val applicationScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    val database: ChefAgentDatabase by lazy {
        ChefAgentDatabase.getInstance(context)
    }

    val prepListDao by lazy { database.prepListDao() }
    val inventoryDao by lazy { database.inventoryDao() }
    val recipeDao by lazy { database.recipeDao() }
    val banquetDao by lazy { database.banquetDao() }
    val syncEventDao by lazy { database.syncEventDao() }

    val prepRepository: PrepRepository by lazy {
        PrepRepository(prepListDao, syncEventDao)
    }

    val inventoryRepository: InventoryRepository by lazy {
        InventoryRepository(inventoryDao, syncEventDao)
    }

    val recipeRepository: RecipeRepository by lazy {
        RecipeRepository(recipeDao, syncEventDao)
    }

    val banquetRepository: BanquetRepository by lazy {
        BanquetRepository(banquetDao, prepListDao, syncEventDao)
    }

    val syncRepository: SyncRepository by lazy {
        SyncRepository(syncEventDao)
    }

    val profileStateManager: ProfileStateManager by lazy {
        ProfileStateManager()
    }

    val scaleRecipeQuantityUseCase: ScaleRecipeQuantityUseCase by lazy {
        ScaleRecipeQuantityUseCase()
    }

    val calculateRecipeCostUseCase: CalculateRecipeCostUseCase by lazy {
        CalculateRecipeCostUseCase()
    }

    val generateDailyPrepListUseCase: GenerateDailyPrepListUseCase by lazy {
        GenerateDailyPrepListUseCase()
    }

    val peerSyncEngine: PeerSyncEngine by lazy {
        PeerSyncEngine(context, syncEventDao)
    }

    init {
        // Asynchronously check and populate initial seed data if DB is fresh
        applicationScope.launch {
            try {
                if (recipeDao.getRecipeCount() == 0) {
                    recipeDao.insertRecipePackageBatch(
                        SeedDataGenerator.ingredients,
                        SeedDataGenerator.recipes,
                        SeedDataGenerator.recipeIngredients
                    )
                }
                if (inventoryDao.getInventoryCount() == 0) {
                    inventoryDao.insertAll(SeedDataGenerator.inventoryItems)
                }
                if (prepListDao.getPrepItemCount() == 0) {
                    prepListDao.insertPrepItems(SeedDataGenerator.prepItems)
                }
                if (banquetDao.getBanquetCount() == 0) {
                    banquetDao.insertBanquetEvents(SeedDataGenerator.banquetEvents)
                }
            } catch (e: Exception) {
                android.util.Log.e("AppContainer", "Error initializing seed data", e)
            }
        }

        // Start P2P local discovery
        peerSyncEngine.startEngine()
    }
}
