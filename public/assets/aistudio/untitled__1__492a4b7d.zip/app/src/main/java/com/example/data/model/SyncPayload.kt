package com.example.data.model

data class SyncPayload(
    val eventId: String,
    val entityType: String,
    val operationType: String,
    val payloadJson: String,
    val timestamp: Long,
    val originNode: String = "CHEF_AGENT_TERMINAL"
)

enum class SyncPeerStatus {
    OFFLINE,
    DISCOVERING,
    PAIRED,
    SYNCING,
    ONLINE
}
