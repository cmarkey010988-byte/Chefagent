package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "ingredients")
data class IngredientEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val category: String, // e.g., "Meat", "Produce", "Dairy", "Dry Goods", "Seafood"
    val unitOfMeasure: String, // e.g., "LB", "OZ", "GAL", "CASE", "EA"
    val currentCostPerUnit: Double,
    val vendorName: String,
    val vendorItemCode: String,
    val lastUpdatedTimestamp: Long = System.currentTimeMillis()
)
