package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(
    tableName = "recipe_ingredients",
    primaryKeys = ["recipeId", "ingredientId"],
    foreignKeys = [
        ForeignKey(
            entity = RecipeEntity::class,
            parentColumns = ["id"],
            childColumns = ["recipeId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = IngredientEntity::class,
            parentColumns = ["id"],
            childColumns = ["ingredientId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index(value = ["recipeId"]), Index(value = ["ingredientId"])]
)
data class RecipeIngredientEntity(
    val recipeId: String,
    val ingredientId: String,
    val requiredQuantity: Double,
    val unitOfMeasure: String,
    val wasteFactorPercentage: Double = 0.0 // e.g., 5.0 for trim loss
)
