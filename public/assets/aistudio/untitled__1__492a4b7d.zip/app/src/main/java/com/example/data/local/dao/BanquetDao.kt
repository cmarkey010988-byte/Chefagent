package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.example.data.local.entities.BanquetEventEntity
import com.example.data.local.entities.PrepItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BanquetDao {

    @Query("SELECT * FROM banquet_events ORDER BY eventDateTimestamp ASC")
    fun observeAllBanquetEvents(): Flow<List<BanquetEventEntity>>

    @Query("SELECT * FROM banquet_events WHERE id = :id LIMIT 1")
    suspend fun getBanquetEventById(id: String): BanquetEventEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBanquetEvent(event: BanquetEventEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBanquetEvents(events: List<BanquetEventEntity>)

    @Query("UPDATE banquet_events SET status = :status WHERE id = :id")
    suspend fun updateBanquetStatus(id: String, status: String)

    @Query("SELECT COUNT(*) FROM banquet_events")
    suspend fun getBanquetCount(): Int

    @Transaction
    suspend fun scheduleBanquetWithPrepItems(
        event: BanquetEventEntity,
        prepItems: List<PrepItemEntity>,
        prepListDao: PrepListDao
    ) {
        insertBanquetEvent(event)
        prepListDao.insertPrepItems(prepItems)
    }
}
