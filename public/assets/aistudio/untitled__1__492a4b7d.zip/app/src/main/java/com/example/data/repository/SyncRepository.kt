package com.example.data.repository

import com.example.data.local.dao.SyncEventDao
import com.example.data.local.entities.SyncEventEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class SyncRepository(
    private val syncEventDao: SyncEventDao
) {

    fun observePendingEvents(): Flow<List<SyncEventEntity>> = syncEventDao.observePendingEvents()

    fun observeRecentEvents(): Flow<List<SyncEventEntity>> = syncEventDao.observeRecentEvents()

    suspend fun getPendingEvents(): List<SyncEventEntity> = withContext(Dispatchers.IO) {
        syncEventDao.getPendingEvents()
    }

    suspend fun flushPendingEvents(): Int = withContext(Dispatchers.IO) {
        val pending = syncEventDao.getPendingEvents()
        if (pending.isNotEmpty()) {
            syncEventDao.markEventsAsSynced(pending.map { it.eventId })
        }
        pending.size
    }

    suspend fun clearSyncedEvents() = withContext(Dispatchers.IO) {
        syncEventDao.clearSyncedEvents()
    }
}
