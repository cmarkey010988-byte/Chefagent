package com.example.data.model

data class CostingBreakdown(
    val recipeId: String,
    val recipeName: String,
    val portionCost: Double,
    val targetMenuPrice: Double,
    val actualFoodCostPercentage: Double,
    val grossMarginDollars: Double,
    val isMarginSqueezed: Boolean,
    val ingredientBreakdown: List<IngredientCostItem> = emptyList()
)

data class IngredientCostItem(
    val name: String,
    val quantity: Double,
    val unit: String,
    val unitCost: Double,
    val totalCost: Double
)
