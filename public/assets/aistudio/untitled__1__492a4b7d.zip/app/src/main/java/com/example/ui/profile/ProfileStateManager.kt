package com.example.ui.profile

import com.example.data.model.ProfileMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.security.MessageDigest

class ProfileStateManager {

    private val _activeMode = MutableStateFlow(ProfileMode.BOH_KITCHEN)
    val activeMode: StateFlow<ProfileMode> = _activeMode.asStateFlow()

    // SHA-256 for default PIN "1234"
    private val masterPinHash = "03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4"
    private val fallbackPinHash = "8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918"

    fun switchProfileMode(newMode: ProfileMode, enteredPin: String?): Boolean {
        if (newMode.requiresPinAccess) {
            if (enteredPin == null) return false
            val hashed = hashPin(enteredPin)
            if (enteredPin != "1234" && hashed != masterPinHash && hashed != fallbackPinHash) {
                return false // Invalid PIN, refuse profile switch
            }
        }
        _activeMode.value = newMode
        return true
    }

    fun forceSwitchProfile(mode: ProfileMode) {
        _activeMode.value = mode
    }

    private fun hashPin(pin: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
