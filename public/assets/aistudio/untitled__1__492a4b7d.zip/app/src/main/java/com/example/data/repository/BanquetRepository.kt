package com.example.data.repository

import com.example.data.local.dao.BanquetDao
import com.example.data.local.dao.PrepListDao
import com.example.data.local.dao.SyncEventDao
import com.example.data.local.entities.BanquetEventEntity
import com.example.data.local.entities.PrepItemEntity
import com.example.data.local.entities.SyncEventEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.UUID

class BanquetRepository(
    private val banquetDao: BanquetDao,
    private val prepListDao: PrepListDao,
    private val syncEventDao: SyncEventDao
) {

    fun observeAllBanquetEvents(): Flow<List<BanquetEventEntity>> = banquetDao.observeAllBanquetEvents()

    suspend fun updateEventStatus(id: String, status: String) = withContext(Dispatchers.IO) {
        banquetDao.updateBanquetStatus(id, status)
        syncEventDao.insertSyncEvent(
            SyncEventEntity(
                eventId = UUID.randomUUID().toString(),
                entityType = "BANQUET",
                operationType = "UPDATE",
                payloadJson = """{"eventId":"$id","newStatus":"$status"}""",
                timestamp = System.currentTimeMillis(),
                isSynced = false
            )
        )
    }

    suspend fun scheduleBanquet(event: BanquetEventEntity, prepItems: List<PrepItemEntity>) = withContext(Dispatchers.IO) {
        banquetDao.scheduleBanquetWithPrepItems(event, prepItems, prepListDao)
        syncEventDao.insertSyncEvent(
            SyncEventEntity(
                eventId = UUID.randomUUID().toString(),
                entityType = "BANQUET",
                operationType = "INSERT",
                payloadJson = """{"eventName":"${event.eventName}","guestCount":${event.guestCount}}""",
                timestamp = System.currentTimeMillis(),
                isSynced = false
            )
        )
    }

    suspend fun seedBanquets(events: List<BanquetEventEntity>) = withContext(Dispatchers.IO) {
        banquetDao.insertBanquetEvents(events)
    }
}
