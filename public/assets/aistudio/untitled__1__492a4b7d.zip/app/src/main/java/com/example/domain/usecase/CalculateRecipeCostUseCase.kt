package com.example.domain.usecase

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class MenuMarginAnalysis(
    val recipeId: String,
    val recipeName: String,
    val category: String = "A La Carte",
    val portionCost: Double,
    val targetMenuPrice: Double,
    val actualFoodCostPercentage: Double,
    val grossMarginDollars: Double,
    val isMarginSqueezed: Boolean,
    val targetFoodCostPct: Double = 28.0
)

class CalculateRecipeCostUseCase {

    suspend fun execute(
        recipeId: String,
        recipeName: String,
        category: String = "A La Carte",
        ingredientCosts: List<Pair<Double, Double>>, // Pair(Quantity, CostPerUnit)
        targetPrice: Double,
        targetFoodCostPct: Double = 28.0
    ): MenuMarginAnalysis = withContext(Dispatchers.Default) {
        val totalRecipeCost = ingredientCosts.sumOf { (qty, cost) -> qty * cost }
        val actualFcp = if (targetPrice > 0.0) (totalRecipeCost / targetPrice) * 100.0 else 0.0
        val marginDollars = targetPrice - totalRecipeCost
        val isSqueezed = actualFcp > targetFoodCostPct

        MenuMarginAnalysis(
            recipeId = recipeId,
            recipeName = recipeName,
            category = category,
            portionCost = totalRecipeCost,
            targetMenuPrice = targetPrice,
            actualFoodCostPercentage = actualFcp,
            grossMarginDollars = marginDollars,
            isMarginSqueezed = isSqueezed,
            targetFoodCostPct = targetFoodCostPct
        )
    }
}
