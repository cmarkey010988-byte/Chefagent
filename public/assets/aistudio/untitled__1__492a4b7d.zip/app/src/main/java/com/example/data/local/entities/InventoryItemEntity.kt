package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "inventory_items")
data class InventoryItemEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val ingredientId: String,
    val ingredientName: String = "",
    val unitOfMeasure: String = "LB",
    val storageLocation: String, // "Walk-In Cooler", "Dry Prep", "Freezer", "Bar"
    val currentOnHandQuantity: Double,
    val parLevelQuantity: Double,
    val reorderPointQuantity: Double,
    val unitCost: Double = 0.0,
    val lastAuditTimestamp: Long = System.currentTimeMillis(),
    val auditedByProfile: String = "BOH_CHEF" // "BOH_CHEF" or "FOH_MANAGER"
)
