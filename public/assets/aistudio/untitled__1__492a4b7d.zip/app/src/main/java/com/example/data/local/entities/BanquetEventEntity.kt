package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "banquet_events")
data class BanquetEventEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val eventName: String, // e.g., "Member-Guest Gala Dinner"
    val guestCount: Int,
    val eventDateTimestamp: Long,
    val status: String, // "PLANNED", "PREP_IN_PROGRESS", "COMPLETED", "CANCELLED"
    val totalContractValue: Double,
    val primaryEntreeRecipeId: String? = null,
    val secondaryEntreeRecipeId: String? = null
)
