package com.example.data.repository

import com.example.data.local.dao.RecipeDao
import com.example.data.local.dao.SyncEventDao
import com.example.data.local.entities.IngredientEntity
import com.example.data.local.entities.RecipeEntity
import com.example.data.local.entities.RecipeIngredientEntity
import com.example.data.local.entities.SyncEventEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.UUID

class RecipeRepository(
    private val recipeDao: RecipeDao,
    private val syncEventDao: SyncEventDao
) {

    fun observeAllRecipes(): Flow<List<RecipeEntity>> = recipeDao.observeAllRecipes()

    fun observeAllIngredients(): Flow<List<IngredientEntity>> = recipeDao.observeAllIngredients()

    suspend fun getRecipeById(recipeId: String): RecipeEntity? = withContext(Dispatchers.IO) {
        recipeDao.getRecipeById(recipeId)
    }

    suspend fun getIngredientsForRecipe(recipeId: String): List<RecipeIngredientEntity> = withContext(Dispatchers.IO) {
        recipeDao.getIngredientsForRecipe(recipeId)
    }

    suspend fun getAllIngredients(): List<IngredientEntity> = withContext(Dispatchers.IO) {
        recipeDao.getAllIngredients()
    }

    suspend fun insertRecipeWithIngredients(
        recipe: RecipeEntity,
        ingredients: List<RecipeIngredientEntity>
    ) = withContext(Dispatchers.IO) {
        recipeDao.insertRecipeWithIngredients(recipe, ingredients)
        syncEventDao.insertSyncEvent(
            SyncEventEntity(
                eventId = UUID.randomUUID().toString(),
                entityType = "RECIPE",
                operationType = "INSERT",
                payloadJson = """{"recipeId":"${recipe.id}","recipeName":"${recipe.name}"}""",
                timestamp = System.currentTimeMillis(),
                isSynced = false
            )
        )
    }

    suspend fun seedRecipeCatalog(
        ingredients: List<IngredientEntity>,
        recipes: List<RecipeEntity>,
        recipeIngredients: List<RecipeIngredientEntity>
    ) = withContext(Dispatchers.IO) {
        recipeDao.insertRecipePackageBatch(ingredients, recipes, recipeIngredients)
    }
}
