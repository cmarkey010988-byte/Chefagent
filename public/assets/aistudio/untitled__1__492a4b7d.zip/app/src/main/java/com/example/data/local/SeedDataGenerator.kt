package com.example.data.local

import com.example.data.local.entities.BanquetEventEntity
import com.example.data.local.entities.IngredientEntity
import com.example.data.local.entities.InventoryItemEntity
import com.example.data.local.entities.PrepItemEntity
import com.example.data.local.entities.RecipeEntity
import com.example.data.local.entities.RecipeIngredientEntity

object SeedDataGenerator {

    val ingredients = listOf(
        IngredientEntity(
            id = "ing-beef-tenderloin",
            name = "Prime Beef Tenderloin (PSMO)",
            category = "Meat",
            unitOfMeasure = "LB",
            currentCostPerUnit = 24.50,
            vendorName = "Sysco Fine Meats",
            vendorItemCode = "SYS-BF-109A"
        ),
        IngredientEntity(
            id = "ing-halibut",
            name = "Wild Pacific Halibut Fillet",
            category = "Seafood",
            unitOfMeasure = "LB",
            currentCostPerUnit = 28.00,
            vendorName = "Oceanic Seafoods Co.",
            vendorItemCode = "OSC-HAL-442"
        ),
        IngredientEntity(
            id = "ing-truffle-butter",
            name = "Black Truffle Compound Butter",
            category = "Dairy",
            unitOfMeasure = "LB",
            currentCostPerUnit = 32.00,
            vendorName = "Gourmet Artisan Pantry",
            vendorItemCode = "GAP-TRF-09"
        ),
        IngredientEntity(
            id = "ing-heavy-cream",
            name = "Grade A Heavy Whipping Cream 40%",
            category = "Dairy",
            unitOfMeasure = "GAL",
            currentCostPerUnit = 14.25,
            vendorName = "Highland Valley Dairy",
            vendorItemCode = "HVD-CRM-40"
        ),
        IngredientEntity(
            id = "ing-shallots",
            name = "French Grey Shallots",
            category = "Produce",
            unitOfMeasure = "LB",
            currentCostPerUnit = 3.80,
            vendorName = "Valley Fresh Produce",
            vendorItemCode = "VFP-SHL-12"
        ),
        IngredientEntity(
            id = "ing-microgreens",
            name = "Petite Culinary Microgreens",
            category = "Produce",
            unitOfMeasure = "OZ",
            currentCostPerUnit = 2.40,
            vendorName = "Local Greens Hydro",
            vendorItemCode = "LGH-MIC-01"
        ),
        IngredientEntity(
            id = "ing-arborio",
            name = "Carnaroli Risotto Rice (Aged)",
            category = "Dry Goods",
            unitOfMeasure = "LB",
            currentCostPerUnit = 4.20,
            vendorName = "Ital-Foods Direct",
            vendorItemCode = "ITL-CRN-5K"
        ),
        IngredientEntity(
            id = "ing-russet",
            name = "Idaho Russet Burbank Potatoes #1",
            category = "Produce",
            unitOfMeasure = "LB",
            currentCostPerUnit = 0.95,
            vendorName = "Valley Fresh Produce",
            vendorItemCode = "VFP-POT-50"
        ),
        IngredientEntity(
            id = "ing-belgian-choc",
            name = "Belgian Dark Callebaut 70.5%",
            category = "Dry Goods",
            unitOfMeasure = "LB",
            currentCostPerUnit = 12.50,
            vendorName = "Pastry Pro Supply",
            vendorItemCode = "PPS-CAL-70"
        ),
        IngredientEntity(
            id = "ing-wild-mushrooms",
            name = "Fresh Foraged Morel & Chanterelle",
            category = "Produce",
            unitOfMeasure = "LB",
            currentCostPerUnit = 22.00,
            vendorName = "Forager Guild NW",
            vendorItemCode = "FGN-MSH-03"
        )
    )

    val recipes = listOf(
        RecipeEntity(
            id = "rec-1",
            name = "Prime Tenderloin Au Poivre",
            category = "A La Carte",
            standardYieldQuantity = 10.0,
            yieldUnit = "Portions",
            laborMinutesRequired = 25,
            targetFoodCostPercentage = 28.0,
            isBanquetCompatible = true,
            targetMenuPrice = 58.00
        ),
        RecipeEntity(
            id = "rec-2",
            name = "Pan-Roasted Halibut & Beurre Blanc",
            category = "A La Carte",
            standardYieldQuantity = 8.0,
            yieldUnit = "Portions",
            laborMinutesRequired = 20,
            targetFoodCostPercentage = 26.0,
            isBanquetCompatible = true,
            targetMenuPrice = 48.00
        ),
        RecipeEntity(
            id = "rec-3",
            name = "Wild Mushroom & Truffle Risotto",
            category = "Prep Base",
            standardYieldQuantity = 15.0,
            yieldUnit = "Portions",
            laborMinutesRequired = 35,
            targetFoodCostPercentage = 22.0,
            isBanquetCompatible = true,
            targetMenuPrice = 32.00
        ),
        RecipeEntity(
            id = "rec-4",
            name = "Country Club Banquet Roast Beef",
            category = "Banquet Entree",
            standardYieldQuantity = 40.0,
            yieldUnit = "Portions",
            laborMinutesRequired = 45,
            targetFoodCostPercentage = 29.0,
            isBanquetCompatible = true,
            targetMenuPrice = 44.00
        ),
        RecipeEntity(
            id = "rec-5",
            name = "Warm Belgian Dark Chocolate Lava Tart",
            category = "Dessert",
            standardYieldQuantity = 12.0,
            yieldUnit = "Portions",
            laborMinutesRequired = 30,
            targetFoodCostPercentage = 18.0,
            isBanquetCompatible = true,
            targetMenuPrice = 16.00
        )
    )

    val recipeIngredients = listOf(
        // Prime Tenderloin Au Poivre (10 portions)
        RecipeIngredientEntity(
            recipeId = "rec-1",
            ingredientId = "ing-beef-tenderloin",
            requiredQuantity = 5.0, // 8 oz per portion = 5 lb total
            unitOfMeasure = "LB",
            wasteFactorPercentage = 8.0 // 8% trim loss
        ),
        RecipeIngredientEntity(
            recipeId = "rec-1",
            ingredientId = "ing-shallots",
            requiredQuantity = 0.75,
            unitOfMeasure = "LB",
            wasteFactorPercentage = 5.0
        ),
        RecipeIngredientEntity(
            recipeId = "rec-1",
            ingredientId = "ing-heavy-cream",
            requiredQuantity = 0.25,
            unitOfMeasure = "GAL",
            wasteFactorPercentage = 0.0
        ),
        RecipeIngredientEntity(
            recipeId = "rec-1",
            ingredientId = "ing-truffle-butter",
            requiredQuantity = 0.5,
            unitOfMeasure = "LB",
            wasteFactorPercentage = 0.0
        ),

        // Halibut (8 portions)
        RecipeIngredientEntity(
            recipeId = "rec-2",
            ingredientId = "ing-halibut",
            requiredQuantity = 3.5,
            unitOfMeasure = "LB",
            wasteFactorPercentage = 6.0
        ),
        RecipeIngredientEntity(
            recipeId = "rec-2",
            ingredientId = "ing-shallots",
            requiredQuantity = 0.5,
            unitOfMeasure = "LB",
            wasteFactorPercentage = 5.0
        ),
        RecipeIngredientEntity(
            recipeId = "rec-2",
            ingredientId = "ing-microgreens",
            requiredQuantity = 4.0,
            unitOfMeasure = "OZ",
            wasteFactorPercentage = 0.0
        ),

        // Risotto Base (15 portions)
        RecipeIngredientEntity(
            recipeId = "rec-3",
            ingredientId = "ing-arborio",
            requiredQuantity = 3.0,
            unitOfMeasure = "LB",
            wasteFactorPercentage = 2.0
        ),
        RecipeIngredientEntity(
            recipeId = "rec-3",
            ingredientId = "ing-wild-mushrooms",
            requiredQuantity = 2.5,
            unitOfMeasure = "LB",
            wasteFactorPercentage = 5.0
        ),
        RecipeIngredientEntity(
            recipeId = "rec-3",
            ingredientId = "ing-truffle-butter",
            requiredQuantity = 0.75,
            unitOfMeasure = "LB",
            wasteFactorPercentage = 0.0
        ),

        // Banquet Roast (40 portions)
        RecipeIngredientEntity(
            recipeId = "rec-4",
            ingredientId = "ing-beef-tenderloin",
            requiredQuantity = 20.0,
            unitOfMeasure = "LB",
            wasteFactorPercentage = 10.0
        ),
        RecipeIngredientEntity(
            recipeId = "rec-4",
            ingredientId = "ing-russet",
            requiredQuantity = 18.0,
            unitOfMeasure = "LB",
            wasteFactorPercentage = 12.0
        ),

        // Lava Tart (12 portions)
        RecipeIngredientEntity(
            recipeId = "rec-5",
            ingredientId = "ing-belgian-choc",
            requiredQuantity = 2.2,
            unitOfMeasure = "LB",
            wasteFactorPercentage = 1.0
        ),
        RecipeIngredientEntity(
            recipeId = "rec-5",
            ingredientId = "ing-heavy-cream",
            requiredQuantity = 0.20,
            unitOfMeasure = "GAL",
            wasteFactorPercentage = 0.0
        )
    )

    val inventoryItems = listOf(
        InventoryItemEntity(
            id = "inv-1",
            ingredientId = "ing-beef-tenderloin",
            ingredientName = "Prime Beef Tenderloin (PSMO)",
            unitOfMeasure = "LB",
            storageLocation = "Walk-In Cooler",
            currentOnHandQuantity = 14.5,
            parLevelQuantity = 35.0,
            reorderPointQuantity = 18.0, // Low stock alert!
            unitCost = 24.50,
            auditedByProfile = "BOH_CHEF"
        ),
        InventoryItemEntity(
            id = "inv-2",
            ingredientId = "ing-halibut",
            ingredientName = "Wild Pacific Halibut Fillet",
            unitOfMeasure = "LB",
            storageLocation = "Walk-In Cooler",
            currentOnHandQuantity = 26.0,
            parLevelQuantity = 30.0,
            reorderPointQuantity = 15.0,
            unitCost = 28.00,
            auditedByProfile = "BOH_CHEF"
        ),
        InventoryItemEntity(
            id = "inv-3",
            ingredientId = "ing-truffle-butter",
            ingredientName = "Black Truffle Compound Butter",
            unitOfMeasure = "LB",
            storageLocation = "Walk-In Cooler",
            currentOnHandQuantity = 8.5,
            parLevelQuantity = 10.0,
            reorderPointQuantity = 4.0,
            unitCost = 32.00,
            auditedByProfile = "FOH_MANAGER"
        ),
        InventoryItemEntity(
            id = "inv-4",
            ingredientId = "ing-heavy-cream",
            ingredientName = "Grade A Heavy Cream 40%",
            unitOfMeasure = "GAL",
            storageLocation = "Walk-In Cooler",
            currentOnHandQuantity = 4.0,
            parLevelQuantity = 12.0,
            reorderPointQuantity = 5.0, // Low stock alert!
            unitCost = 14.25,
            auditedByProfile = "FOH_MANAGER"
        ),
        InventoryItemEntity(
            id = "inv-5",
            ingredientId = "ing-shallots",
            ingredientName = "French Grey Shallots",
            unitOfMeasure = "LB",
            storageLocation = "Dry Prep",
            currentOnHandQuantity = 16.0,
            parLevelQuantity = 20.0,
            reorderPointQuantity = 8.0,
            unitCost = 3.80,
            auditedByProfile = "BOH_CHEF"
        ),
        InventoryItemEntity(
            id = "inv-6",
            ingredientId = "ing-arborio",
            ingredientName = "Carnaroli Risotto Rice (Aged)",
            unitOfMeasure = "LB",
            storageLocation = "Dry Prep",
            currentOnHandQuantity = 42.0,
            parLevelQuantity = 50.0,
            reorderPointQuantity = 20.0,
            unitCost = 4.20,
            auditedByProfile = "BOH_CHEF"
        ),
        InventoryItemEntity(
            id = "inv-7",
            ingredientId = "ing-russet",
            ingredientName = "Idaho Russet Potatoes #1",
            unitOfMeasure = "LB",
            storageLocation = "Dry Prep",
            currentOnHandQuantity = 110.0,
            parLevelQuantity = 150.0,
            reorderPointQuantity = 50.0,
            unitCost = 0.95,
            auditedByProfile = "BOH_CHEF"
        ),
        InventoryItemEntity(
            id = "inv-8",
            ingredientId = "ing-belgian-choc",
            ingredientName = "Belgian Dark Callebaut 70.5%",
            unitOfMeasure = "LB",
            storageLocation = "Dry Prep",
            currentOnHandQuantity = 22.0,
            parLevelQuantity = 25.0,
            reorderPointQuantity = 10.0,
            unitCost = 12.50,
            auditedByProfile = "BOH_CHEF"
        ),
        InventoryItemEntity(
            id = "inv-9",
            ingredientId = "ing-wild-mushrooms",
            ingredientName = "Fresh Foraged Morel & Chanterelle",
            unitOfMeasure = "LB",
            storageLocation = "Freezer",
            currentOnHandQuantity = 11.0,
            parLevelQuantity = 15.0,
            reorderPointQuantity = 6.0,
            unitCost = 22.00,
            auditedByProfile = "FOH_MANAGER"
        ),
        InventoryItemEntity(
            id = "inv-10",
            ingredientId = "ing-microgreens",
            ingredientName = "Petite Culinary Microgreens",
            unitOfMeasure = "OZ",
            storageLocation = "Bar",
            currentOnHandQuantity = 12.0,
            parLevelQuantity = 16.0,
            reorderPointQuantity = 6.0,
            unitCost = 2.40,
            auditedByProfile = "FOH_MANAGER"
        )
    )

    val prepItems = listOf(
        PrepItemEntity(
            id = "prep-1",
            recipeId = "rec-1",
            recipeName = "Prime Rib Au Jus & Peppercorn Demi",
            targetQuantity = 6.0,
            completedQuantity = 0.0,
            unitOfMeasure = "GAL",
            stationAssignment = "Sauce/Sauté",
            priorityLevel = 1,
            isCompleted = false,
            assignedCookName = "Chef Bruce"
        ),
        PrepItemEntity(
            id = "prep-2",
            recipeId = "rec-1",
            recipeName = "Center-Cut Filet Butchery & Tie",
            targetQuantity = 45.0,
            completedQuantity = 45.0,
            unitOfMeasure = "Portions",
            stationAssignment = "Butchery",
            priorityLevel = 1,
            isCompleted = true, // Already finished for service
            assignedCookName = "Chef Bruce"
        ),
        PrepItemEntity(
            id = "prep-3",
            recipeId = "rec-2",
            recipeName = "Pacific Halibut Portioning & Pin-Boning",
            targetQuantity = 32.0,
            completedQuantity = 0.0,
            unitOfMeasure = "Portions",
            stationAssignment = "Butchery",
            priorityLevel = 1,
            isCompleted = false,
            assignedCookName = "Cook Marco"
        ),
        PrepItemEntity(
            id = "prep-4",
            recipeId = "rec-3",
            recipeName = "Truffle Compound Butter Logs",
            targetQuantity = 12.0,
            completedQuantity = 0.0,
            unitOfMeasure = "Logs",
            stationAssignment = "Garde Manger",
            priorityLevel = 2,
            isCompleted = false,
            assignedCookName = "Cook Leo"
        ),
        PrepItemEntity(
            id = "prep-5",
            recipeId = "rec-3",
            recipeName = "Carnaroli Risotto Pre-Par Cook",
            targetQuantity = 20.0,
            completedQuantity = 0.0,
            unitOfMeasure = "Orders",
            stationAssignment = "Sauce/Sauté",
            priorityLevel = 2,
            isCompleted = false,
            assignedCookName = "Cook Leo"
        ),
        PrepItemEntity(
            id = "prep-6",
            recipeId = "rec-5",
            recipeName = "Chocolate Tartlet Shells & Ganache",
            targetQuantity = 50.0,
            completedQuantity = 0.0,
            unitOfMeasure = "EA",
            stationAssignment = "Pastry",
            priorityLevel = 2,
            isCompleted = false,
            assignedCookName = "Pastry Chef Elena"
        ),
        PrepItemEntity(
            id = "prep-7",
            recipeId = "rec-2",
            recipeName = "Shallot White Wine Reduction (Beurre Blanc)",
            targetQuantity = 3.5,
            completedQuantity = 0.0,
            unitOfMeasure = "QT",
            stationAssignment = "Sauce/Sauté",
            priorityLevel = 1,
            isCompleted = false,
            assignedCookName = "Chef Bruce"
        )
    )

    val banquetEvents = listOf(
        BanquetEventEntity(
            id = "banquet-1",
            eventName = "Member-Guest Invitational Gala Dinner",
            guestCount = 350,
            eventDateTimestamp = System.currentTimeMillis() + (86400000L * 2), // 2 days out
            status = "PREP_IN_PROGRESS",
            totalContractValue = 38500.00,
            primaryEntreeRecipeId = "rec-4",
            secondaryEntreeRecipeId = "rec-2"
        ),
        BanquetEventEntity(
            id = "banquet-2",
            eventName = "Governors Club Championship Luncheon",
            guestCount = 140,
            eventDateTimestamp = System.currentTimeMillis() + (86400000L * 4), // 4 days out
            status = "PLANNED",
            totalContractValue = 11200.00,
            primaryEntreeRecipeId = "rec-1",
            secondaryEntreeRecipeId = "rec-2"
        ),
        BanquetEventEntity(
            id = "banquet-3",
            eventName = "Charity Foundation Wine Pairing Dinner",
            guestCount = 85,
            eventDateTimestamp = System.currentTimeMillis() + (86400000L * 7),
            status = "PLANNED",
            totalContractValue = 14875.00,
            primaryEntreeRecipeId = "rec-1",
            secondaryEntreeRecipeId = "rec-5"
        )
    )
}
