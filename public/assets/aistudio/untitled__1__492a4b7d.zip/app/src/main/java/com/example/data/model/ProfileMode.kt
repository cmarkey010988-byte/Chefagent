package com.example.data.model

enum class ProfileMode(
    val displayName: String,
    val defaultMinTouchTargetDp: Int,
    val requiresPinAccess: Boolean
) {
    BOH_KITCHEN(
        displayName = "Kitchen Line Execution",
        defaultMinTouchTargetDp = 64, // Touch target scaling for line environment & speed
        requiresPinAccess = false
    ),
    FOH_MANAGEMENT(
        displayName = "Management & Costing Dashboard",
        defaultMinTouchTargetDp = 48, // Dense layout for analytics & inventory auditing
        requiresPinAccess = true
    )
}
