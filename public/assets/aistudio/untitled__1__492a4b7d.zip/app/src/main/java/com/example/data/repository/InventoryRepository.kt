package com.example.data.repository

import com.example.data.local.dao.InventoryDao
import com.example.data.local.dao.SyncEventDao
import com.example.data.local.entities.InventoryItemEntity
import com.example.data.local.entities.SyncEventEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.UUID

class InventoryRepository(
    private val inventoryDao: InventoryDao,
    private val syncEventDao: SyncEventDao
) {

    fun observeInventoryByLocation(location: String): Flow<List<InventoryItemEntity>> {
        return if (location == "ALL") {
            inventoryDao.observeAllInventory()
        } else {
            inventoryDao.observeInventoryByLocation(location)
        }
    }

    fun observeAllInventory(): Flow<List<InventoryItemEntity>> {
        return inventoryDao.observeAllInventory()
    }

    fun observeLowStockItems(): Flow<List<InventoryItemEntity>> {
        return inventoryDao.observeLowStockItems()
    }

    suspend fun auditItemQuantity(id: String, newQty: Double, auditorProfile: String) = withContext(Dispatchers.IO) {
        val timestamp = System.currentTimeMillis()
        inventoryDao.auditItemQuantity(id, newQty, timestamp, auditorProfile)

        // Delta sync event
        syncEventDao.insertSyncEvent(
            SyncEventEntity(
                eventId = UUID.randomUUID().toString(),
                entityType = "INVENTORY",
                operationType = "UPDATE",
                payloadJson = """{"itemId":"$id","auditedQty":$newQty,"auditedBy":"$auditorProfile","timestamp":$timestamp}""",
                timestamp = timestamp,
                isSynced = false
            )
        )
    }

    suspend fun seedInventory(items: List<InventoryItemEntity>) = withContext(Dispatchers.IO) {
        inventoryDao.insertAll(items)
    }
}
