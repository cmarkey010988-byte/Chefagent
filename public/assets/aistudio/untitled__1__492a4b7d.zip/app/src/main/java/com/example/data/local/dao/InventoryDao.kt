package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.example.data.local.entities.InventoryItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface InventoryDao {

    @Query("SELECT * FROM inventory_items WHERE storageLocation = :location ORDER BY ingredientName ASC, ingredientId ASC")
    fun observeInventoryByLocation(location: String): Flow<List<InventoryItemEntity>>

    @Query("SELECT * FROM inventory_items ORDER BY storageLocation ASC, ingredientName ASC")
    fun observeAllInventory(): Flow<List<InventoryItemEntity>>

    @Query("SELECT * FROM inventory_items WHERE currentOnHandQuantity <= reorderPointQuantity ORDER BY currentOnHandQuantity ASC")
    fun observeLowStockItems(): Flow<List<InventoryItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun updateInventoryItem(item: InventoryItemEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<InventoryItemEntity>)

    @Query("SELECT COUNT(*) FROM inventory_items")
    suspend fun getInventoryCount(): Int

    @Transaction
    @Query("UPDATE inventory_items SET currentOnHandQuantity = :newQty, lastAuditTimestamp = :timestamp, auditedByProfile = :profile WHERE id = :id")
    suspend fun auditItemQuantity(id: String, newQty: Double, timestamp: Long, profile: String)

    @Transaction
    suspend fun batchAudit(audits: List<Triple<String, Double, String>>, timestamp: Long) {
        for ((id, qty, profile) in audits) {
            auditItemQuantity(id, qty, timestamp, profile)
        }
    }
}
