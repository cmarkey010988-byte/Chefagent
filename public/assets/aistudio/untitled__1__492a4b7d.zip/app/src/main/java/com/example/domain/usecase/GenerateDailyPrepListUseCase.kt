package com.example.domain.usecase

import com.example.data.local.entities.PrepItemEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

class GenerateDailyPrepListUseCase {

    suspend fun execute(
        station: String?,
        timestamp: Long = System.currentTimeMillis()
    ): List<PrepItemEntity> = withContext(Dispatchers.Default) {
        val sampleItems = listOf(
            PrepItemEntity(
                id = UUID.randomUUID().toString(),
                recipeId = "rec-1",
                recipeName = "Prime Rib Au Jus Base",
                targetQuantity = 8.0,
                completedQuantity = 0.0,
                unitOfMeasure = "GAL",
                stationAssignment = "Sauce/Sauté",
                priorityLevel = 1,
                isCompleted = false,
                assignedCookName = "Chef Bruce",
                shiftedDateTimestamp = timestamp
            ),
            PrepItemEntity(
                id = UUID.randomUUID().toString(),
                recipeId = "rec-2",
                recipeName = "Dry-Aged Tenderloin Medallions",
                targetQuantity = 45.0,
                completedQuantity = 0.0,
                unitOfMeasure = "Portions",
                stationAssignment = "Butchery",
                priorityLevel = 1,
                isCompleted = false,
                assignedCookName = "Chef Bruce",
                shiftedDateTimestamp = timestamp
            ),
            PrepItemEntity(
                id = UUID.randomUUID().toString(),
                recipeId = "rec-3",
                recipeName = "Truffle Herb Butter Ramekins",
                targetQuantity = 60.0,
                completedQuantity = 0.0,
                unitOfMeasure = "EA",
                stationAssignment = "Garde Manger",
                priorityLevel = 2,
                isCompleted = false,
                assignedCookName = "Cook Leo",
                shiftedDateTimestamp = timestamp
            ),
            PrepItemEntity(
                id = UUID.randomUUID().toString(),
                recipeId = "rec-4",
                recipeName = "Lemon Thyme Tartlet Shells",
                targetQuantity = 80.0,
                completedQuantity = 0.0,
                unitOfMeasure = "EA",
                stationAssignment = "Pastry",
                priorityLevel = 2,
                isCompleted = false,
                assignedCookName = "Pastry Chef Elena",
                shiftedDateTimestamp = timestamp
            ),
            PrepItemEntity(
                id = UUID.randomUUID().toString(),
                recipeId = "rec-5",
                recipeName = "Wild Mushroom Demi-Glace",
                targetQuantity = 4.0,
                completedQuantity = 0.0,
                unitOfMeasure = "GAL",
                stationAssignment = "Sauce/Sauté",
                priorityLevel = 2,
                isCompleted = false,
                assignedCookName = "Chef Bruce",
                shiftedDateTimestamp = timestamp
            ),
            PrepItemEntity(
                id = UUID.randomUUID().toString(),
                recipeId = "rec-6",
                recipeName = "Halibut Portioning & Pin-Boning",
                targetQuantity = 30.0,
                completedQuantity = 0.0,
                unitOfMeasure = "Portions",
                stationAssignment = "Butchery",
                priorityLevel = 1,
                isCompleted = false,
                assignedCookName = "Cook Marco",
                shiftedDateTimestamp = timestamp
            )
        )

        if (station == null || station == "ALL") {
            sampleItems
        } else {
            sampleItems.filter { it.stationAssignment == station }
        }
    }
}
