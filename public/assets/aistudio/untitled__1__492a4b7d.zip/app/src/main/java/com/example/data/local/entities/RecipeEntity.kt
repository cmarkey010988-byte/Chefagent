package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "recipes")
data class RecipeEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val category: String, // e.g., "Banquet Entree", "A La Carte", "Prep Base", "Dessert"
    val standardYieldQuantity: Double,
    val yieldUnit: String, // e.g., "Portions", "Gallons", "Pounds"
    val laborMinutesRequired: Int,
    val targetFoodCostPercentage: Double = 28.0, // Default country club standard target
    val isBanquetCompatible: Boolean = true,
    val targetMenuPrice: Double = 0.0
)
