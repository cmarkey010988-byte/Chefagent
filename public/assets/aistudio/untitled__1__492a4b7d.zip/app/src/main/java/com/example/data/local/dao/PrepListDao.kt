package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.example.data.local.entities.PrepItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PrepListDao {

    @Query("SELECT * FROM prep_items WHERE shiftedDateTimestamp >= :startOfDayTimestamp ORDER BY priorityLevel ASC, isCompleted ASC, recipeName ASC")
    fun observeActivePrepItems(startOfDayTimestamp: Long): Flow<List<PrepItemEntity>>

    @Query("SELECT * FROM prep_items ORDER BY priorityLevel ASC, isCompleted ASC, recipeName ASC")
    fun observeAllPrepItems(): Flow<List<PrepItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdatePrepItem(item: PrepItemEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrepItems(items: List<PrepItemEntity>)

    @Query("UPDATE prep_items SET completedQuantity = :completedQty, isCompleted = :isDone WHERE id = :prepItemId")
    suspend fun updatePrepProgress(prepItemId: String, completedQty: Double, isDone: Boolean)

    @Query("DELETE FROM prep_items WHERE id = :prepItemId")
    suspend fun deletePrepItem(prepItemId: String)

    @Query("SELECT COUNT(*) FROM prep_items")
    suspend fun getPrepItemCount(): Int

    @Transaction
    suspend fun resetAndSeedPrep(items: List<PrepItemEntity>) {
        insertPrepItems(items)
    }
}
