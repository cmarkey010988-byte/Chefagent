package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.BanquetDao
import com.example.data.local.dao.InventoryDao
import com.example.data.local.dao.PrepListDao
import com.example.data.local.dao.RecipeDao
import com.example.data.local.dao.SyncEventDao
import com.example.data.local.entities.BanquetEventEntity
import com.example.data.local.entities.IngredientEntity
import com.example.data.local.entities.InventoryItemEntity
import com.example.data.local.entities.PrepItemEntity
import com.example.data.local.entities.RecipeEntity
import com.example.data.local.entities.RecipeIngredientEntity
import com.example.data.local.entities.SyncEventEntity

@Database(
    entities = [
        IngredientEntity::class,
        RecipeEntity::class,
        RecipeIngredientEntity::class,
        InventoryItemEntity::class,
        PrepItemEntity::class,
        BanquetEventEntity::class,
        SyncEventEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ChefAgentDatabase : RoomDatabase() {
    abstract fun prepListDao(): PrepListDao
    abstract fun inventoryDao(): InventoryDao
    abstract fun recipeDao(): RecipeDao
    abstract fun banquetDao(): BanquetDao
    abstract fun syncEventDao(): SyncEventDao

    companion object {
        @Volatile
        private var INSTANCE: ChefAgentDatabase? = null

        fun getInstance(context: Context): ChefAgentDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ChefAgentDatabase::class.java,
                    "chef_agent_master.db"
                )
                    .setJournalMode(JournalMode.WRITE_AHEAD_LOGGING) // High throughput for concurrent writes and reads
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
