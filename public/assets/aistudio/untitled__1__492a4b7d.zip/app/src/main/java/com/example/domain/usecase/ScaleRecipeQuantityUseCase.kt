package com.example.domain.usecase

import com.example.data.local.entities.RecipeIngredientEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class ScaledIngredient(
    val ingredientId: String,
    val ingredientName: String = "",
    val originalQuantity: Double,
    val scaledQuantity: Double,
    val unitOfMeasure: String,
    val estimatedCost: Double
)

data class RecipeScalingResult(
    val recipeId: String,
    val recipeName: String,
    val baseYield: Double,
    val targetYield: Double,
    val yieldUnit: String,
    val scaleMultiplier: Double,
    val scaledIngredients: List<ScaledIngredient>,
    val totalEstimatedBatchCost: Double,
    val portionCost: Double
)

class ScaleRecipeQuantityUseCase {

    suspend fun execute(
        recipeId: String,
        recipeName: String,
        baseYield: Double,
        targetYield: Double,
        yieldUnit: String,
        ingredients: List<RecipeIngredientEntity>,
        unitCosts: Map<String, Double>,
        ingredientNames: Map<String, String> = emptyMap()
    ): RecipeScalingResult = withContext(Dispatchers.Default) {
        if (baseYield <= 0.0 || targetYield <= 0.0) {
            return@withContext RecipeScalingResult(
                recipeId = recipeId,
                recipeName = recipeName,
                baseYield = baseYield,
                targetYield = targetYield,
                yieldUnit = yieldUnit,
                scaleMultiplier = 1.0,
                scaledIngredients = emptyList(),
                totalEstimatedBatchCost = 0.0,
                portionCost = 0.0
            )
        }

        val scaleMultiplier = targetYield / baseYield

        val scaledList = ingredients.map { item ->
            val rawScaledQty = item.requiredQuantity * scaleMultiplier
            val grossQtyWithWaste = rawScaledQty * (1.0 + (item.wasteFactorPercentage / 100.0))
            val unitCost = unitCosts[item.ingredientId] ?: 0.0
            val cost = grossQtyWithWaste * unitCost

            ScaledIngredient(
                ingredientId = item.ingredientId,
                ingredientName = ingredientNames[item.ingredientId] ?: item.ingredientId,
                originalQuantity = item.requiredQuantity,
                scaledQuantity = grossQtyWithWaste,
                unitOfMeasure = item.unitOfMeasure,
                estimatedCost = cost
            )
        }

        val totalCost = scaledList.sumOf { it.estimatedCost }
        val portionCost = if (targetYield > 0.0) totalCost / targetYield else 0.0

        RecipeScalingResult(
            recipeId = recipeId,
            recipeName = recipeName,
            baseYield = baseYield,
            targetYield = targetYield,
            yieldUnit = yieldUnit,
            scaleMultiplier = scaleMultiplier,
            scaledIngredients = scaledList,
            totalEstimatedBatchCost = totalCost,
            portionCost = portionCost
        )
    }
}
