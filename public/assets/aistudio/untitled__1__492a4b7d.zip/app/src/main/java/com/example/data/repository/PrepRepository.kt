package com.example.data.repository

import com.example.data.local.dao.PrepListDao
import com.example.data.local.dao.SyncEventDao
import com.example.data.local.entities.PrepItemEntity
import com.example.data.local.entities.SyncEventEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.UUID

class PrepRepository(
    private val prepListDao: PrepListDao,
    private val syncEventDao: SyncEventDao
) {

    fun observeActivePrepItems(startOfDayTimestamp: Long): Flow<List<PrepItemEntity>> {
        return prepListDao.observeActivePrepItems(startOfDayTimestamp)
    }

    fun observeAllPrepItems(): Flow<List<PrepItemEntity>> {
        return prepListDao.observeAllPrepItems()
    }

    suspend fun updatePrepProgress(item: PrepItemEntity, completed: Boolean) = withContext(Dispatchers.IO) {
        val newCompletedQty = if (completed) item.targetQuantity else 0.0
        prepListDao.updatePrepProgress(item.id, newCompletedQty, completed)

        // Append to immutable delta sync queue
        syncEventDao.insertSyncEvent(
            SyncEventEntity(
                eventId = UUID.randomUUID().toString(),
                entityType = "PREP",
                operationType = "UPDATE",
                payloadJson = """{"prepId":"${item.id}","recipeName":"${item.recipeName}","isCompleted":$completed,"completedQty":$newCompletedQty}""",
                timestamp = System.currentTimeMillis(),
                isSynced = false
            )
        )
    }

    suspend fun addPrepItem(item: PrepItemEntity) = withContext(Dispatchers.IO) {
        prepListDao.insertOrUpdatePrepItem(item)
        syncEventDao.insertSyncEvent(
            SyncEventEntity(
                eventId = UUID.randomUUID().toString(),
                entityType = "PREP",
                operationType = "INSERT",
                payloadJson = """{"prepId":"${item.id}","recipeName":"${item.recipeName}","targetQty":${item.targetQuantity}}""",
                timestamp = System.currentTimeMillis(),
                isSynced = false
            )
        )
    }

    suspend fun deletePrepItem(prepItemId: String) = withContext(Dispatchers.IO) {
        prepListDao.deletePrepItem(prepItemId)
    }

    suspend fun seedSamplePrep(items: List<PrepItemEntity>) = withContext(Dispatchers.IO) {
        prepListDao.resetAndSeedPrep(items)
    }
}
