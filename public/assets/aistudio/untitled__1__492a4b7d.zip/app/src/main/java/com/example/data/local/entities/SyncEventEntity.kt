package com.example.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "sync_event_queue")
data class SyncEventEntity(
    @PrimaryKey(autoGenerate = true) val sequenceId: Long = 0,
    val eventId: String = UUID.randomUUID().toString(),
    val entityType: String, // "PREP", "INVENTORY", "RECIPE", "INVOICE", "BANQUET"
    val operationType: String, // "INSERT", "UPDATE", "DELETE"
    val payloadJson: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isSynced: Boolean = false
)
