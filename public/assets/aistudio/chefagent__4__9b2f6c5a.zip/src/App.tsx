import React, { useState } from 'react';
import { ChefProvider, useChef } from './context/ChefContext';
import { Header } from './components/Header';
import { PinModal } from './components/PinModal';
import { StationPrepBoard } from './components/boh/StationPrepBoard';
import { BOHRecipeScaler } from './components/boh/BOHRecipeScaler';
import { SanitationLogView } from './components/boh/SanitationLogView';
import { FloorPlanView } from './components/foh/FloorPlanView';
import { ShiftManagementView } from './components/foh/ShiftManagementView';
import { PurchaseOrderView } from './components/procurement/PurchaseOrderModal';
import { FOHInventoryAudit } from './components/foh/FOHInventoryAudit';
import { FOHMarginDashboard } from './components/foh/FOHMarginDashboard';
import { EventScheduleView } from './components/events/EventScheduleView';
import { OnHandMenuGeneratorView } from './components/menu/OnHandMenuGeneratorView';
import { CulinaryCopilotDrawer } from './components/copilot/CulinaryCopilotDrawer';
import { PlatingMediaStudioModal } from './components/media/PlatingMediaStudioModal';
import { ExecutiveWorkflowHUD } from './components/executive/ExecutiveWorkflowHUD';
import { ExpirationMenuModal } from './components/executive/ExpirationMenuModal';
import { VisionScanModal } from './components/inventory/VisionScanModal';
import { AuditDiffModal } from './components/inventory/AuditDiffModal';
import {
  Flame,
  Scale,
  TrendingUp,
  ClipboardList,
  Sparkles,
  LayoutGrid,
  ShieldCheck,
  Calendar,
  Truck,
  Users,
  Thermometer,
} from 'lucide-react';

const AppContent: React.FC = () => {
  const { activeProfile, terminology } = useChef();
  const isBOH = activeProfile === 'BOH_KITCHEN';

  // Sub-tabs for BOH
  const [bohTab, setBohTab] = useState<'prep' | 'scaling' | 'sanitation' | 'onhand'>('prep');

  // Sub-tabs for FOH
  const [fohTab, setFohTab] = useState<
    'floor' | 'shifts' | 'procurement' | 'inventory' | 'margin' | 'events' | 'onhand'
  >('floor');

  return (
    <div
      className={`min-h-screen transition-colors duration-250 ${
        isBOH ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'
      }`}
    >
      {/* Top Universal App Bar */}
      <Header />

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* Profile Context Banner & Sub-Navigation */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span
                className={`text-xs font-black uppercase tracking-wider px-2 py-0.5 rounded-md ${
                  isBOH
                    ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                    : 'bg-indigo-100 text-indigo-900 border border-indigo-200'
                }`}
              >
                {isBOH ? 'BOH Kitchen Line' : 'FOH Operations & Control'}
              </span>
              <span className="text-xs text-slate-500 font-medium">
                {isBOH
                  ? 'High-Contrast OLED Touch Terminal (Chef Bruce & Line Station Stewards)'
                  : 'Executive Service Management & Floor Logistics (Manager Ashley)'}
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black tracking-tight mt-1">
              {isBOH ? (
                bohTab === 'prep'
                  ? 'Line Station Prep & Mise en Place'
                  : bohTab === 'scaling'
                  ? 'Yield & Sub-Recipe Engineering'
                  : bohTab === 'sanitation'
                  ? 'Warewash, Sanitation & Chemical Logs'
                  : 'Smart On-Hand Menu Generator'
              ) : (
                fohTab === 'floor'
                  ? 'Floor Plan, Table Pacing & 86 Sync'
                  : fohTab === 'shifts'
                  ? 'Labor Roster & Pre-Shift Handoff'
                  : fohTab === 'procurement'
                  ? 'Procurement & Supplier PO Generator'
                  : fohTab === 'inventory'
                  ? 'Inventory Par Reconciliation'
                  : fohTab === 'margin'
                  ? 'Food Cost % & Menu Margins'
                  : fohTab === 'events'
                  ? `${terminology.eventLabel} Event Schedule`
                  : 'Par-to-Plate Surplus Menu Optimization'
              )}
            </h1>
          </div>

          {/* Sub-view Segmented Tabs */}
          <div
            className={`p-1 rounded-xl flex items-center border transition-colors overflow-x-auto scrollbar-none max-w-full ${
              isBOH
                ? 'bg-slate-900 border-slate-800'
                : 'bg-white border-slate-200 shadow-xs'
            }`}
          >
            {isBOH ? (
              <>
                <button
                  type="button"
                  onClick={() => setBohTab('prep')}
                  className={`min-h-[42px] px-3.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                    bohTab === 'prep'
                      ? 'bg-amber-500 text-slate-950 font-black shadow-md shadow-amber-500/20'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Flame className="w-3.5 h-3.5" />
                  <span>Station Prep</span>
                </button>
                <button
                  type="button"
                  onClick={() => setBohTab('scaling')}
                  className={`min-h-[42px] px-3.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                    bohTab === 'scaling'
                      ? 'bg-amber-500 text-slate-950 font-black shadow-md shadow-amber-500/20'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Scale className="w-3.5 h-3.5" />
                  <span>Recipe Scaler</span>
                </button>
                <button
                  type="button"
                  onClick={() => setBohTab('sanitation')}
                  className={`min-h-[42px] px-3.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                    bohTab === 'sanitation'
                      ? 'bg-amber-500 text-slate-950 font-black shadow-md shadow-amber-500/20'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Thermometer className="w-3.5 h-3.5" />
                  <span>Sanitation & Temps</span>
                </button>
                <button
                  type="button"
                  onClick={() => setBohTab('onhand')}
                  className={`min-h-[42px] px-3.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                    bohTab === 'onhand'
                      ? 'bg-amber-500 text-slate-950 font-black shadow-md shadow-amber-500/20'
                      : 'text-amber-400/80 hover:text-amber-300'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Par-to-Plate AI</span>
                </button>
              </>
            ) : (
              <>
                <button
                  type="button"
                  onClick={() => setFohTab('floor')}
                  className={`min-h-[42px] px-3 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                    fohTab === 'floor'
                      ? 'bg-indigo-900 text-white font-black shadow-md'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <LayoutGrid className="w-3.5 h-3.5" />
                  <span>Floor Plan</span>
                </button>
                <button
                  type="button"
                  onClick={() => setFohTab('shifts')}
                  className={`min-h-[42px] px-3 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                    fohTab === 'shifts'
                      ? 'bg-indigo-900 text-white font-black shadow-md'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Users className="w-3.5 h-3.5" />
                  <span>Shift Brief</span>
                </button>
                <button
                  type="button"
                  onClick={() => setFohTab('procurement')}
                  className={`min-h-[42px] px-3 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                    fohTab === 'procurement'
                      ? 'bg-indigo-900 text-white font-black shadow-md'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Truck className="w-3.5 h-3.5" />
                  <span>Procurement & POs</span>
                </button>
                <button
                  type="button"
                  onClick={() => setFohTab('inventory')}
                  className={`min-h-[42px] px-3 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                    fohTab === 'inventory'
                      ? 'bg-indigo-900 text-white font-black shadow-md'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <ClipboardList className="w-3.5 h-3.5" />
                  <span>Inventory</span>
                </button>
                <button
                  type="button"
                  onClick={() => setFohTab('margin')}
                  className={`min-h-[42px] px-3 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                    fohTab === 'margin'
                      ? 'bg-indigo-900 text-white font-black shadow-md'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>Margins (28%)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setFohTab('events')}
                  className={`min-h-[42px] px-3 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                    fohTab === 'events'
                      ? 'bg-indigo-900 text-white font-black shadow-md'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Events</span>
                </button>
                <button
                  type="button"
                  onClick={() => setFohTab('onhand')}
                  className={`min-h-[42px] px-3 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                    fohTab === 'onhand'
                      ? 'bg-indigo-900 text-white font-black shadow-md'
                      : 'text-indigo-700 hover:text-indigo-900'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Par-to-Plate</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* Dynamic Body Content */}
        {isBOH ? (
          bohTab === 'prep' ? (
            <StationPrepBoard />
          ) : bohTab === 'scaling' ? (
            <BOHRecipeScaler />
          ) : bohTab === 'sanitation' ? (
            <SanitationLogView />
          ) : (
            <OnHandMenuGeneratorView />
          )
        ) : fohTab === 'floor' ? (
          <FloorPlanView />
        ) : fohTab === 'shifts' ? (
          <ShiftManagementView />
        ) : fohTab === 'procurement' ? (
          <PurchaseOrderView />
        ) : fohTab === 'inventory' ? (
          <FOHInventoryAudit />
        ) : fohTab === 'margin' ? (
          <FOHMarginDashboard />
        ) : fohTab === 'events' ? (
          <EventScheduleView />
        ) : (
          <OnHandMenuGeneratorView />
        )}
      </main>

      {/* Slide-out Gemini Culinary Copilot Drawer */}
      <CulinaryCopilotDrawer />

      {/* High-Resolution Plating & Marketing Studio Modal */}
      <PlatingMediaStudioModal />

      {/* FOH Access Security PIN Keypad Modal */}
      <PinModal />

      {/* AI Executive Workflow HUD Banner */}
      <ExecutiveWorkflowHUD />

      {/* AI Vision Shelf-Counting Scanner & Viewfinder Modal */}
      <VisionScanModal />

      {/* AI Vision Side-by-Side Reconciliation Diff Modal */}
      <AuditDiffModal />

      {/* AI Expiration-Driven Daily Specials & Banquet Proposals Modal */}
      <ExpirationMenuModal />
    </div>
  );
};

export default function App() {
  return (
    <ChefProvider>
      <AppContent />
    </ChefProvider>
  );
}
