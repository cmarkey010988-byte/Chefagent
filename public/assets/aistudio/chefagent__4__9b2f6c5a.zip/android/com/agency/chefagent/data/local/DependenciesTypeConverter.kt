package com.agency.chefagent.data.local

import androidx.room.TypeConverter
import org.json.JSONArray

/**
 * DependenciesTypeConverter.kt
 *
 * Room DB TypeConverter converting List<String> of prerequisite prep item IDs
 * to and from a lightweight JSON string column without external reflection overhead.
 */
class DependenciesTypeConverter {

    @TypeConverter
    fun fromDependenciesList(dependencies: List<String>?): String {
        if (dependencies.isNullOrEmpty()) return "[]"
        val jsonArray = JSONArray()
        dependencies.forEach { jsonArray.put(it) }
        return jsonArray.toString()
    }

    @TypeConverter
    fun toDependenciesList(dependenciesString: String?): List<String> {
        if (dependenciesString.isNullOrBlank() || dependenciesString == "[]") {
            return emptyList()
        }
        val list = mutableListOf<String>()
        try {
            val jsonArray = JSONArray(dependenciesString)
            for (i in 0 until jsonArray.length()) {
                list.add(jsonArray.getString(i))
            }
        } catch (_: Exception) {
            // Graceful fallback for non-json comma separated or empty strings
            return dependenciesString.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        }
        return list
    }
}
